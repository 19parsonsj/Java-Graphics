import javax.swing.*;
import java.awt.*;
import java.util.Collections;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.*;
import java.util.concurrent.TimeUnit;

//class that implements action listener and establish variables
public class MemoryGame implements ActionListener{
    JFrame frame = new JFrame();
    JPanel panel = new JPanel();
    JButton[] buttons = new JButton[16];
    Boolean[] flipped = new Boolean[16];
    Integer[] slots = {-1,-1};
    Integer[] button = {-1,-1};
    ImageIcon img;
    JButton inc;
    JButton corr;
    JButton start;
    JButton restart;
    int one = -2;
    int nullify = -1;
    int incorrect = 0;
    int correct = 0;

//memory game
    public MemoryGame() {

//initializing of panels
        //holds tries
        JPanel panel1 = new JPanel();
        //holds correct counter
        JPanel panel2 = new JPanel();
        //holds blank button for placeholder
        JPanel panel3 = new JPanel();
        //holds restart button
        JPanel panel4 = new JPanel();

        //button that shows tries counter
        inc = new JButton("Tries: " + String.valueOf(incorrect) + "");
        //setting it to not be opaque, adding action lister
        inc.setOpaque(false);
        inc.setContentAreaFilled(false);
        inc.setBorderPainted(false);
        inc.addActionListener(this);

        //button for correct counter, adds action listener and sets presets
        corr = new JButton("Correct: " + String.valueOf(correct) + "");
        corr.setOpaque(false);
        corr.setContentAreaFilled(false);
        corr.setBorderPainted(false);
        corr.addActionListener(this);

        //add blank jbutton for place holder
        JButton start = new JButton("");
        start.setOpaque(false);
        start.setContentAreaFilled(false);
        start.setBorderPainted(false);
        //restart button to restart the game
        JButton restart = new JButton("RESTART");

        //action listener for restart button
        restart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //close frame
                frame.dispose();
                //call memory game to run again
                new MemoryGame();

            }
        });

//set layout of frame
        GridLayout layout = new GridLayout(5, 5, 0, 2);
        panel1.setLayout(new GridLayout(2,1,0,2));
        panel2.setLayout(new GridLayout(2,1,0,2));
        panel.setLayout(new GridLayout(5, 5, 0, 2));
//add buttons to panel and add individual panels to main panel
        panel1.add(inc);
        panel2.add(corr);
        panel3.add(start);
        panel4.add(restart);
        panel.add(panel1);
        panel.add(panel2);
        panel.add(panel3);
        panel.add(panel4);

        //create button for cards
        JButton question = new JButton("?");
        Arrays.fill(flipped, Boolean.FALSE);
        //used for randomization
        Integer[] nums = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        List<Integer> list = Arrays.asList(nums);
        Collections.shuffle(list);
        list.toArray(nums);

        int value = 0;

        //assign each button to random spot and add action listener
        for (int i = 0; i < 16; i++) {
            value = nums[i];
            buttons[value] = new JButton("?");
            panel.add(buttons[value]);
            buttons[value].addActionListener(this);
        }

        //add panel to frame and pack, set visible and size
        frame.add(panel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        frame.setSize(500, 500);
        frame.setVisible(true);
    }

    //action listener for cards
        public void actionPerformed(ActionEvent e){
        //see if we need to flip back over the previous cards
            if (nullify == 0)
            {
                picnull();
            }

//see if game is over
        if (allTrue() == false){
        //refers to button pressed
        Object source = e.getSource();


        //loop through and see where the button was and give it a randomly assigned image
        for (int i = 0; i <16; i++) {

            if (source == buttons[i]) {
                if (i > 7) {
                    img = new ImageIcon("cat" + String.valueOf((i-7) + ".PNG"));
                    one = (i-7);
                } else {
                    img = new ImageIcon("cat" + String.valueOf((i + 1) + ".PNG"));
                    one = i + 1;
                }
                //keep track of which image was put on first button
                if (slots[0] == -1){
                    button[0] = i;

                }
                //keep track if first button already has an image and what the second button image is
                else if (slots[1] == -1 && slots[0] > -1){
                    button[1] = i;
                }

                //transform image to fit on button
                Image image = ((ImageIcon) img).getImage();
                Image newimg = image.getScaledInstance(60, 50, java.awt.Image.SCALE_SMOOTH);
                img = new ImageIcon(newimg);
                buttons[i].setText("");
                buttons[i].setIcon(img);
            }

            }
        //call calculate to see if user did not make a match
            try {
                if (calculate(one) == -1){
                    nullify = 0;
                }
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }

    //function for flipping incorrect matched back over
    public void picnull() {

            if (slots[1] > -1 && slots[0] > -1) {

                //wait for three seconds
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                //null the icon and set text back to "?"
                buttons[button[0]].setText("?");
                buttons[button[0]].setIcon(null);
                buttons[button[1]].setText("?");
                buttons[button[1]].setIcon(null);
                incorrect += 1;
                //update number of tries
                inc.setText("Tries: " + String.valueOf(incorrect) + "");
//reset trackers of images and button position
                slots[0] = -1;
                slots[1] = -1;
                button[0] = -1;
                button[1] = -1;
                nullify = -1;

            }
        }
//function to see if all cards have been flipped
    private boolean allTrue() {
        for (boolean b : flipped) {
            if (!b) {
                return false;
            }
        }
        return true;
    }

//function to calculate if the user made a match or not - or if they have only flipped one button
        public int calculate(int found) throws InterruptedException {
//only one button has been pushed
            if (slots[0] == -1) {
                slots[0] = found;
                return 0;
            }
            //two buttons have been pushed
            else {
                slots[1] = found;
                //they are a match
                if (slots[0] == slots[1]) {
                    flipped[button[0]] = true;
                    flipped[button[1]] = true;
                    correct += 1;
                    //update number of correct matches and tries
                    corr.setText("Correct: " + String.valueOf(correct) + "");
                    inc.setText("Tries: " + String.valueOf(incorrect) + "");
                    incorrect += 1;
                //reset trackers of images and buttons pushed
                    slots[0] = -1;
                    slots[1] = -1;
                    button[0] = -1;
                    button[1] = -1;
                    return 1;
                }
                //not a match- update number of incorrect attempts
                if (slots[0]!=slots[1]){
                    incorrect +=.5;
                    inc.setText("Tries: " + String.valueOf(incorrect) + "");
                    return -1;
                }
            }
            return -2;
        }

        //main for running memory game
    public static void main(String[] args) {
        new MemoryGame();

    }
}

