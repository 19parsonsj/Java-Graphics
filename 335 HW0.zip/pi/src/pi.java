import java.lang.Math;
public class pi {
    //check for 8th digit after decimal precision by truncation
    static int check(double value) {
        //multiply imported value by 4 to get pi from pi/4
        value = value * 4;
        //truncating with flooring the value to the 8th decimal
        value = value * Math.pow(10, 8);
        value = Math.floor(value);
        value = value / Math.pow(10, 8);
        //check to see if we have the value to 8th digit of precision
        if (value == 3.14159265) {
            //returns by letting main know value was found
            return 1;

        }
        //returns by letting main know not found
        return 0;


    }
    //main
    public static void main(String[] args) {
        //initialize pi, count for num terms, sign, and found for while loop
        double pi = 1.0;
        int count = 1;
        int sign = 0;
        int found = 1;
        //while loop until found 8th digit precise number
        while (found !=0){
            //for loop for adding nth term to pi
            for (int n = 3; n < 999999999; n += 2) {
                //add 1 to total number of terms
                count += 1;
                //check for sign
                if (sign == 0) {
                    pi = pi + (double) -1 / n;
                    sign = 1;

                } else {
                    pi = pi + (double) 1 / n;
                    sign = 0;

                }
                //call check to see if our value is precise and print out number of terms if value is a match
                if (check(pi) == 1) {
                    System.out.println(count);
                    //terminate for and while loop
                    n = 1000000000;
                    found = 0;
                }
            }
        }
    }
}

