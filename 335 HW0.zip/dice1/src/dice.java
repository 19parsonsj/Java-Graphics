import java.lang.Math;


//dice problem number one:
public class dice {
    public static void main(String[] args) {
        //runs set to 100 and increase by power of 10 until 100000
        int runs = 100;
        //count number of max output;
        int count = 0;
        int die1 = 0;
        int die2 = 0;
        //while loop to make sure we do not go over 100000 runs
        while (runs < 1000000) {
            //for loop testing to see if both die add to 32 for each run
            // adds to count if they are equal
            for (int i = 0; i < runs; i++) {
                //Math.random
                die1 = (int) (Math.random() * 20) +1;
                die2 = (int) (Math.random() * 12) +1;
                if (die1 + die2 == 32) {
                    count += 1;
                }
            }
            //print out info of run number and adjacent count of max output in the runs
            System.out.printf("%d: %d max out\n", runs,count);
            //increase run number by power of 10
            runs *=10;

        }
    }

}
