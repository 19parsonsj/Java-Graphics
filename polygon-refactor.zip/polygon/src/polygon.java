import javax.swing.*;
import java.awt.*;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.GeneralPath;
import java.util.HashMap;
import java.util.Timer;

public class polygon extends JPanel {

    private Polygon newpoly;
    private Polygon redrawPoly;
    private static int count = 0;
    private int[] xValue;
    private int pointDrag;
    private String bColor = "BLUE";
    private boolean fill = false;
    private HashMap<String, Color> map = new  HashMap<String, Color>();
    private int[] yValue;
    private int sumx=0;
    private int sumy=0;
    private boolean remove = false;
    private int centroidX;
    private int centroidY;
    private boolean needrotate = false;
    private double rot=50;
    private boolean isDragging = false;

    //private final List<Point2D> Positions = new ArrayList<Point2D>();

    // private static Point pos = panel.getMousePosition();

polygon() {

    super(Boolean.parseBoolean("Drawing Red Polygon"));
    Timer increaserTimer = new Timer("MyTimer");
    setVisible (true);
    xValue = new int[0];
    yValue = new int[0];
    //newpoly = new Polygon(xValue, yValue, count);




    JPanel drawpanel = new JPanel();
    drawpanel.setLayout(new BorderLayout());
    JPanel poly = new JPanel();
    poly.setBackground(Color.black);
    poly.setPreferredSize(new Dimension(600,600));


    //start button
    JButton start = new JButton("START");
    start.addMouseListener(new MouseAdapter(){
      //  @Override
        public void MouseClicked(ActionEvent e){
            if (e.getSource() == start){
               // System.out.println("clicked");
                needrotate = true;
                repaint();
                needrotate = false;
            }



        }
    });

    JPanel button = new JPanel();
    //stop button
    JButton stop = new JButton("STOP");
    //reset button
    JButton reset = new JButton("RESET");

    button.add(start);
    button.add(stop);
    button.add(reset);

    drawpanel.add(button, BorderLayout.NORTH);

    reset.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
           // reset();
            if (e.getSource() == reset) {

             //   System.out.println("reclicked");

                int[] xValue;
                int[] yValue;
                repaint();


            }
        }
    });

    stop.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
           // stop();
            if (e.getSource() == stop) {
               // System.out.println("stopclicked");
                needrotate = false;
                //System.out.println("stop");

                repaint();
            }
        }
    });

    this.add(poly);
    this.add(drawpanel);



    //stack for ordering of polygon vertice                                                                                 \                       s
    //x
    //ArrayList xValue = new ArrayList();

    //y
    //ArrayList yValue = new ArrayList();

    JLabel label = new JLabel();
    label.setBackground(Color.white);
    label.setForeground(Color.red);
    poly.add(label);
    //mouse click for vertice placement
    poly.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {

            int x = e.getX();
            int y = e.getY();
            sumx += x;
            sumy += y;
            count +=1;

            xValue = addX(count-1, xValue, x);
            yValue = addY(count-1, yValue, y);
            label.setText("X: "+x+" \t Y: "+y); // this sets the JLabel's text
            label.setBounds(x, y, label.getText().length()*2, 20);
           // System.out.println(Arrays.toString(xValue));
           // System.out.println(Arrays.toString(yValue));
           // System.out.println(count);

            setCentroid(newpoly);
            repaint();

        }
        @Override
        public void mousePressed(MouseEvent e){
            //System.out.println("pressed");

            for (int i =0; i < xValue.length; i++){
                if (Math.abs(e.getX() - xValue[i]) < 5 && Math.abs(e.getY() - yValue[i]) < 5) {
                    isDragging = true;
                    pointDrag = i;
                }

            }
        }

    });




    //(1) rubberbanding mouse drag
    //each vertice should be draggable
    poly.addMouseMotionListener(new MouseAdapter() {
        //while getting dragged
        //repeatedly draw and erase the two edges of the polygon that are affected to make it
        //look like the polygon is being interactively reshaped.
                                    @Override
                                    public void mouseDragged(MouseEvent e) {
                                        if (isDragging == true) {
                                           // System.out.println("is dragging ");
                                            int x = e.getX();
                                            int y = e.getY();
                                            xValue[pointDrag] = x;
                                            yValue[pointDrag] = y;
                                            //setCentroid(newpoly);
                                            repaint();
                                        }
                                    }
        //when released
        //draw the final polygon(where the point ended up landing).

                                    @Override
                                    public void mouseReleased(MouseEvent e) {
                                      //  System.out.println("released");
                                        isDragging = false;
                                    }
                                });





    //(2) play animation rotating clockwise through 360 degrees, one degree per frame(i.e., implement both of these modes, and let the user choose)
    //start button handler

    //Use the centroid of the vertices of the polygon as the center of rotation.
    //Decide the timing of the animation so it doesn’t take forever but is viewable in a few seconds.


    //(3) attributes that govern how the polygon is rendered

    //jbuttons
    //colors

    JPanel color = new JPanel();

    JButton red = new JButton("RED");
    red.setForeground(Color.RED);
    color.add(red);
    map.put("RED", Color.RED);
    red.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            bColor = "RED";
            repaint();
        }
    });

    JButton blue = new JButton("BLUE");
    blue.setForeground(Color.BLUE);
    color.add(blue);
    map.put("BLUE", Color.BLUE);
    blue.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            bColor = "BLUE";
            repaint();
        }
    });
    JButton yellow = new JButton("YELLOW");
    yellow.setForeground(Color.YELLOW);
    color.add(yellow);
    map.put("YELLOW", Color.YELLOW);
    yellow.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            bColor = "YELLOW";
            repaint();
        }
    });
    JButton green = new JButton("GREEN");
    green.setForeground(Color.GREEN);
    color.add(green);
    map.put("GREEN", Color.GREEN);
    green.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            bColor = "GREEN";
            repaint();
        }
    });
    JButton purple = new JButton("PURPLE");
    purple.setForeground(Color.MAGENTA);
    color.add(purple);
    map.put("MAGENTA", Color.MAGENTA);
    purple.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            bColor = "MAGENTA";
            repaint();
        }
    });
    drawpanel.add(color);



    //fill/boundary
    //filled
    JPanel filling = new JPanel();
    JButton filled = new JButton("FILL");
    filling.add(filled);
    filled.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            fill = true;
            repaint();
        }
    });
    drawpanel.add(filling, BorderLayout.SOUTH);



    //boundary
    JButton boundary = new JButton("BOUNDARY POLYGON");
    filling.add(boundary);

    //(A) polygon (drawing the lines of the polygon as a closed shape
    boundary.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            fill = false;
            repaint();
        }
    });

    //(B) B-spline (using the points of the polygon as a set of control points to draw all the B-spine curve segments defined by the sequence of points
    JButton bspline = new JButton("BSPLINE");
    filling.add(bspline);
    bspline.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            fill = false;
            repaint();
        }
    });

    //(C) both (a) and (b), i.e., show both the polygon lines AND the B-spline curve segments that the polygon defines.
    JButton both = new JButton("BOUNDARY AND BSPLINE");
    filling.add(both);
    boundary.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            fill = false;
            repaint();
        }
    });

    //STOP button handler
    // animation can be stopped at any time (without having to wait for the complete 360 degree rotation to complete).

    //RESET button handler
    // clears the polygonand allows the user to make a new one.

    //
}
    //set the variable for the right x coordinate (used in banding)
    //public void setRightX(int x){ = x;}

    //set the variable for the right y coordinate (used in banding)
    //public void setRightY(int y){bottomRightY = y;}


    public polygon (int[] xp, int[] yp) {
        newpoly = new Polygon(xp, yp, xp.length);
        setCentroid(newpoly);
    }
    public static int[] addX(int n, int xValue[], int x)
    {
        int i;

        // create a new array of size n+1
        int newarr[] = new int[n + 1];

        // insert the elements from
        // the old array into the new array
        // insert all elements till n
        // then insert x at n+1
        for (i = 0; i < n; i++)
            newarr[i] = xValue[i];

        newarr[n] = x;

        return newarr;
    }
    public static int[] addY(int n, int yValue[], int x)
    {
        int i;

        // create a new array of size n+1
        int newarr[] = new int[n + 1];

        // insert the elements from
        // the old array into the new array
        // insert all elements till n
        // then insert x at n+1
        for (i = 0; i < n; i++)
            newarr[i] = yValue[i];

        newarr[n] = x;

        return newarr;
    }

    /*public void rotate(Graphics g, double modifier){
    //System.out.println("rotate");
        Polygon examplePolygon = new Polygon(xValue, yValue, count);
        Rectangle rect = examplePolygon.getBounds();
        AffineTransform at = new AffineTransform();
        at.rotate(Math.toRadians(modifier), rect.getX() + rect.width/2, rect.getY() + rect.height/2);
        Graphics2D g2d = (Graphics2D) g;
        g2d.draw(at.createTransformedShape(examplePolygon));

        repaint();



    }*/

    public void Rotate(double angle, double pivotX, double pivotY)
    {

    }


    public void paint (Graphics g) {


            super.paint(g);
            Graphics2D g2 = (Graphics2D) g;
            // System.out.println("drawing");
            newpoly = new Polygon(xValue, yValue, count);

            AffineTransform a = AffineTransform.getRotateInstance(1,
                    (double) centroidX, (double) centroidY);

            //GeneralPath path = new GeneralPath();
            //path.moveTo(xValue[0], yValue[0]);
            // path.curveTo(xValue[1], yValue[1], xs[2], ys[2], xs[3], ys[3]);
            //g2d.draw(path);


            g.setColor(map.get(bColor));
            if (fill == true) {
                g.fillPolygon(newpoly);
            }
            g.drawPolygon(newpoly);

            // Establish the transform in the graphics context, then draw/fill
            // g2.setTransform(a);
            // g2.draw(newpoly);
            // g2.fill(newpoly);

            if (needrotate == true) {
                while (needrotate == true) {
                    for (int i = 0; i < 360; i++) {
                        //a.rotate(1);
                        g2.transform(a);
                        g2.draw(newpoly);
                        if (i == 359) {
                            i = 0;
                        }
                    }
                    // g2.translate(-centroidX, -centroidY);

                }
                //a.rotate(Math.PI/180);

                //needrotate = false;

            }
        }


    private void setCentroid (Polygon p) {
        int sumx = 0;
        int sumy = 0;
        for (int i=0; i < count; i++) {
            sumx += xValue[i];
            sumy += yValue[i];
        }
        centroidX = sumx / count;
        centroidY = sumy / count;
        System.out.println("centx: "+ centroidX
                + "centy: " + centroidY);
    }

        public static void main (String[]args){

            JFrame.setDefaultLookAndFeelDecorated(true);
            JFrame frame = new JFrame("Draw Polygon");

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setBackground(Color.white);
            frame.setPreferredSize(new Dimension(600,800));
            frame.add(new polygon());
            //frame.setLayout(new FlowLayout());
            frame.pack();
            frame.setVisible(true);
        }
}





