// problem #2

//(Sieve of Eratosthenes)  A prime number is any integer greater than one that is evenly
// divisible only by itself and 1.The Sieve of Eratosthenes is a method of finding prime numbers.
// It operates as follows:
// A.Create a primitive type boolean array with all elements initialized to true.
// Array elements with prime indices will remain true.  All other array elements will eventually be set to
// false.
// B.Starting with array index 2, determine whether a given element is true.  If so, look through
// the remainder of the array and set to false every element whose index is a multiple of the index for
// the element with value true.Then continue the process with the next element with value true.
// For array index 2, all elements beyond element 2 in the array that have indices which are multiples of 2
// (4, 6, 8, 10, etc.) will be set to false;  for array index 3, all elements beyond element 3 in the array
// that have indices which are multiples of 3 (indices 6, 9, 12, 15, etc.) will be set to false;  and so on.

//When this process completes, the array elements that are still true indicate that the index is a prime number.
// Write a Java program that uses an array of 10,000 elements to compute the “sieve” of prime numbers, display
// all prime numbers less than 10,000, and answer the question “How many primes are there less than 10,000?”.


public class Sieve {
    //call to prime to determine if number is a prime or not
    public static boolean prime(int index) {
        //count to see if we have more than 2 divisors
        int numdiv = 0;
        //loop through to see if the passed in number has a divisor of j
        for (int j = 1; j <= 10000; j++) {
            //if remainder is zero we add one to the count of divisors: numdiv
            if (index % j == 0) {
                numdiv += 1;
            }
        }
        //determine return statements
        // if we have more than 2 divisors, we return false to indicate the number is not prime
        if (numdiv > 2) {
            return false;
        }
        // we return true if numdiv is not greater than two: indicating we passed in a prime number.
        else
            return true;
    }

    //main
    public static void main(String[] args) {
        //initialize variables
        // this is the max number we are looking at
        int MAX = 10000;
        //count of prime numbers in our range
        int count = 0;
        //creating a boolean array with MAX number of elements
        boolean num[] = new boolean[MAX];

        //loop through the array and set every element to true
        for(int i = 0; i < 10000; i++){
            num[i] = true;
        }
        // loop through array to call prime if element is true
        for(int i = 2; i < MAX; i++) {

            if (num[i] == true) {
                //call prime if element is true
                if (prime(i) == false) {
                    //if prime determines our number is not prime
                    //loop through and make all multiples of our number of index n
                    // also false since they will also not be primes
                    for (int n = i; n < MAX; n *= i) {
                        num[n] = false;
                    }
                }
            }
        }
        //loop for printing and counting primes
        for (int k =2; k < MAX; k++) {
            //add 1 to count if our number of index k is true aka. is prime
            if (num[k] == true) {
                count += 1;
               // formatting: 25 numbers a line
                if (count % 25 == 0) {
                    //print out prime numbers and go to new line after 25 numbers
                    System.out.printf("%d \n", k);
                }
                //print out prime numbers
                System.out.printf("%d ", k);
            }
        }
        //print out how many prime numbers were counted in our array.
        System.out.printf("\n\nThere are %d primes less than 10,000.", count);

    }
}
