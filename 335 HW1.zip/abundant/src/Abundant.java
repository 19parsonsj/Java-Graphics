//CS335 HW1 - JP

//An integer number is said to beabundantif the sum of its proper divisors, including 1
// (but not the number itself) are greater than the number.  For example, 24 is abundant,
// because the proper divisors of 24 are 1, 2, 3, 4, 6, 8, and 12.  The sum of those proper
// divisors is 36, which is larger than 24.  The “abundance” of 24 is (36-24) = 12.  Write a
// method abundantand use it to count how many abundant numbers are less than 10,000.
// In addition, identify which of those abundant numbers has the highest “abundance”.
// If there are ties, choose the smallest number.  Output should look like this
// (where “XXX” is your answer):

public class Abundant {
    //method abundance with integer passed in we want to test for abundance
    static int abundance(int integer){
        //sum of proper divisors of integer
        int sum = 0;
        // loop to determine the divisors of integer that are less than the integer
        for (int j = 1; j < integer; j++){
            //if the integer has remainder of 0 when divided with
            // j (our loop to test each number from 1 up to our integer) it is a divisor
            if (integer % j == 0){
                //we add divisor to our sum
                sum += j;
            }
        }
       //test to see if our sum is greater than our integer

        //if the difference between the sum and integer is 0 or less, we do not have an abundance
        if (sum - integer <= 0){
            // abundance = 0
            return 0;
        }
        //else we do have an abundance if sum - integer is greater than 0
        else {
            //we return the abundance
            return sum - integer;
        }

    }
    //main
    public static void main (String[] args){
        //max abundance
        int MAX_A = -1;
        //smallest abundant number with highest abundance
        int MAX_N = 0;
        //count of numbers with abundance
        int count = 0;

        //abundance
        int difference = 0;

        //for loop to call abundance(i) to test if there is an abundance from 1 to our max number we are testing
        for (int i = 1; i < 10000; i++) {
            difference = abundance(i);
            //if what is returned is not zero
            if (difference != 0) {
                //we add to count indicating we have another number with an abundance
                count += 1;
                //if the abundance is equal to our max abundance number stores and our number tested is less
                // than the smallest number stored that has the highest abundance
                if (difference == MAX_A && i < MAX_N) {
                    //we make the new number that was tested the new smallest number with the highest abundance
                    MAX_N = i;
                }

               // or if the new abundance is greater than our recorded max abundance
                else if  (difference > MAX_A) {
                    //the new abundance will be the max abundance
                    MAX_A = difference;
                    // and the number tested will become the new smallest number with largest abundance
                    MAX_N = i;
                }
            }
        }
        // print out how many abundant numbers we counted that are less than 10,000
        System.out.printf("There are %d abundant numbers less than 10,000.\n", count);
        //print out the smallest abundant number (that is less than 10,000) wih the highest abundance
        System.out.printf("The smallest abundant number (less than 10,000) with the highest abundance is %d. \n",MAX_N);

    }
}
