import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.util.Timer;
import java.util.concurrent.TimeUnit;


public class cweasel {
    private JComponent layout = null;


    private static JPanel menucomponent = new JPanel();
    private static JPanel startbutton = new JPanel();
    private static JPanel settings = new JPanel();
    private static JPanel slider = new JPanel();
    private static JLabel clock = new JLabel();
    private MineFieldModel mineFieldModel;
    public final static String bomb = "B";
    private static int s = 0;
    public static int bombs = 40;
    public static int size = 15;
    private int firstclick = 0;
    private boolean explode = false;
    private static int second = 0;
    private static JButton[][] buttons = new JButton[size][size];



    cweasel() {

       /* JPanel displaybar = new JPanel();

        displaybar.add(clock);
        try {
            TimeUnit.SECONDS.sleep(1000);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
        second += 1;
        clock.setText(String.valueOf(second));

       // while (explode != false) {*/

            layout = new JPanel();
            JLabel minesleft = new JLabel();
            int nummines = bombs;
            minesleft.setText("MINES LEFT: " + String.valueOf(nummines));
            layout.setLayout(new FlowLayout());

            layout.setBorder(new EmptyBorder(4, 4, 4, 4));

            mineFieldModel = new MineFieldModel(size, bombs);

            JPanel mineFieldContainer = new JPanel(new GridLayout(
                    size, size, -3, -4));
            layout.add(minesleft);


            layout.add(mineFieldContainer);


            buttons = new JButton[size][size];

            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    buttons[i][j] = new JButton("?");
                    buttons[i][j].setPreferredSize(new Dimension(40, 40));
                    buttons[i][j].setOpaque(true);

                    mineFieldContainer.add(buttons[i][j]);
                    int row = i;
                    int col = j;
                    buttons[i][j].addMouseListener(new MouseAdapter() {
                        public void mouseClicked(MouseEvent e) {
                            if (bombs ==0){
                                layout.removeAll();
                                layout.revalidate();
                                layout.repaint();
                                JLabel won = new JLabel();
                                won.setText("YOU WON!");
                                layout.add(won);
                            }

                            Object source = e.getSource();
                            for (int i = 0; i < size; i++) {
                                for (int j = 0; j < size; j++) {
                                    if (source == buttons[i][j] && e.getButton() == 3) {

                                        if (buttons[i][j].getText() == "F") {

                                          //  if (mineFieldModel.isExposed(i, j)) {
                                                if (mineFieldModel.isBomb(i, j)==true) {
                                                    //if (firstclick > 0) {
                                                        buttons[i][j].setText("B");
                                                    buttons[i][j].setForeground(Color.RED);

                                                        explode = true;
                                                        bomb();
                                                  /*  } else {
                                                        buttons[i][j].setText("");
                                                        bombs -= 1;
                                                    }*/
                                                }
                                                else {

                                                    int count = mineFieldModel.countSurroundingMines(i, j);
                                                    if (count > 0) {
                                                        buttons[i][j].setText("" + count);
                                                        buttons[i][j].setForeground(Color.MAGENTA);

                                                    }
                                                    else {
                                                        reveal(i, j);
                                                    }
                                                }
                                            //}
                                            bombs += 1;
                                        }
                                        else if (buttons[i][j].getText() == "?"){
                                            buttons[i][j].setText("F");
                                            bombs -= 1;
                                            minesleft.setText("MINES LEFT: " +String.valueOf(bombs));
                                        }
                                    }

                                    if (source == buttons[i][j] && e.getButton() != 3 && buttons[i][j].getText() != "F") {

                                       // if (mineFieldModel.isExposed(i, j)) {
                                            if (mineFieldModel.isBomb(i, j)==true) {
                                               // if (firstclick > 0) {
                                                    buttons[i][j].setText("B");
                                                buttons[i][j].setForeground(Color.RED);

                                                    explode = true;
                                                    bomb();
                                               /*} else {
                                                    buttons[i][j].setText("");
                                                    bombs -= 1;
                                                }*/
                                            }
                                            else {

                                                int count = mineFieldModel.countSurroundingMines(i, j);
                                                if (count > 0) {
                                                    buttons[i][j].setText("" + count);
                                                    buttons[i][j].setForeground(Color.MAGENTA);

                                                }
                                                else {
                                                reveal(i, j);
                                            }

                                       // }
                                    }
                                }
                            }
                        }

                        }
                    });

                }
            }
    }



void bomb(){
        layout.removeAll();
        layout.revalidate();
        layout.repaint();
        JLabel explode = new JLabel();
        explode.setText("YOU LOST");
        layout.add(explode);

}
    void reveal(int x, int y) {
        if (buttons[x][y].getText() == "?") {
            buttons[x][y].setText("");
            buttons[x][y].setForeground(Color.MAGENTA);

        }
        if (buttons[x][y].getText() == "") {
if (x+1 < size && x+1 >= 0 && y+1 < size && y+1 >=0) {
    if (buttons[x + 1][y + 1].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x + 1, y + 1) == 0 && mineFieldModel.isBomb(x + 1, y + 1) == false) {
            buttons[x + 1][y + 1].setText("");
            buttons[x+1][y+1].setForeground(Color.MAGENTA);

            reveal(x + 1, y + 1);
        }
        else if (mineFieldModel.isBomb(x + 1, y + 1) == false){
            int count = mineFieldModel.countSurroundingMines(x + 1, y + 1);
                buttons[x+1][y+1].setText("" + count);
            buttons[x+1][y+1].setForeground(Color.MAGENTA);

        }
    }
}
if (x-1 < size && x-1 >=0 && y-1 < size && y-1 >=0) {
    if (buttons[x - 1][y - 1].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x - 1, y - 1) == 0 && mineFieldModel.isBomb(x - 1, y - 1) == false) {
            buttons[x - 1][y - 1].setText("");
            buttons[x-1][y-1].setForeground(Color.MAGENTA);

            reveal(x - 1, y - 1);
        }
        else if (mineFieldModel.isBomb(x - 1, y - 1) == false){
            int count = mineFieldModel.countSurroundingMines(x - 1, y - 1);
            buttons[x-1][y-1].setText("" + count);
            buttons[x-1][y-1].setForeground(Color.MAGENTA);

        }
    }
}
if (x < size && x >= 0 && y+1 < size && y+1 >=0) {
    if (buttons[x][y + 1].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x, y + 1) == 0 && mineFieldModel.isBomb(x , y + 1) == false) {
            buttons[x][y + 1].setText("");
            buttons[x][y+1].setForeground(Color.MAGENTA);

            reveal(x, y + 1);
        }
        else if (mineFieldModel.isBomb(x , y + 1) == false){
            int count = mineFieldModel.countSurroundingMines(x, y + 1);
            buttons[x][y+1].setText("" + count);
            buttons[x][y+1].setForeground(Color.MAGENTA);

        }
    }
}
if (x+1 < size && x+1 >=0 && y < size && y >=0) {
    if (buttons[x + 1][y].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x + 1, y) == 0 && mineFieldModel.isBomb(x + 1, y) == false) {
            buttons[x + 1][y].setText("");
            buttons[x+1][y].setForeground(Color.MAGENTA);

            reveal(x + 1, y);
        }
        else if (mineFieldModel.isBomb(x + 1, y) == false){
            int count = mineFieldModel.countSurroundingMines(x + 1, y);
            buttons[x+1][y].setText("" + count);
            buttons[x+1][y].setForeground(Color.MAGENTA);

        }
    }
}

if (x+1 < size && x+1 >= 0 && y-1 < size && y-1 >=0) {
    if (buttons[x + 1][y - 1].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x + 1, y-1) == 0 && mineFieldModel.isBomb(x + 1, y-1) == false) {
            buttons[x + 1][y - 1].setText("");
            buttons[x+1][y-1].setForeground(Color.MAGENTA);

            reveal(x + 1, y - 1);
        }
        else if (mineFieldModel.isBomb(x + 1, y-1) == false){
            int count = mineFieldModel.countSurroundingMines(x + 1, y-1);
            buttons[x+1][y-1].setText("" + count);
            buttons[x+1][y-1].setForeground(Color.MAGENTA);

        }
    }
}
if (x-1 < size && x-1 >= 0 && y < size && y >=0) {
    if (buttons[x - 1][y].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x - 1, y) == 0 && mineFieldModel.isBomb(x - 1, y) == false) {
            buttons[x - 1][y].setText("");
            buttons[x-1][y].setForeground(Color.MAGENTA);

            reveal(x - 1, y);
        }
        else if (mineFieldModel.isBomb(x - 1, y) == false){
            int count = mineFieldModel.countSurroundingMines(x - 1, y);
            buttons[x-1][y].setText("" + count);
            buttons[x-1][y].setForeground(Color.MAGENTA);

        }
    }
}
if (x < size && x >= 0 && y-1 < size && y-1 >=0) {
    if (buttons[x][y - 1].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x, y - 1) == 0 && mineFieldModel.isBomb(x, y-1) == false) {
            buttons[x][y - 1].setText("");
            buttons[x][y-1].setForeground(Color.MAGENTA);


            reveal(x, y - 1);
        }
        else if (mineFieldModel.isBomb(x, y-1) == false){
            int count = mineFieldModel.countSurroundingMines(x , y-1);
            buttons[x][y-1].setText("" + count);
            buttons[x][y-1].setForeground(Color.MAGENTA);


        }
    }
}
if (x-1 < size && x-1 >= 0 && y+1 < size && y+1 >=0) {
    if (buttons[x - 1][y + 1].getText() == "?") {
        if (mineFieldModel.countSurroundingMines(x, y - 1) == 0 && mineFieldModel.isBomb(x-1, y+1) == false) {
            buttons[x - 1][y + 1].setText("");
            buttons[x-1][y+1].setForeground(Color.MAGENTA);


            reveal(x - 1, y + 1);
        }
        else if (mineFieldModel.isBomb(x-1, y+1) == false){
            int count = mineFieldModel.countSurroundingMines(x-1, y+1);
            buttons[x-1][y+1].setText("" + count);
            buttons[x-1][y+1].setForeground(Color.MAGENTA);


        }
    }
}
        }
    }


    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.metal.MetalLookAndFeel");
        } catch(Exception ignored){}

        cweasel run = new cweasel();
        JFrame f = new JFrame("cweasel");

        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


        settings.setLayout(new GridLayout(2,3));
        slider.setLayout(new GridLayout(2,3));

        //start
        clock.setText("0");
        JButton start = new JButton("START");
        startbutton.add(start);


        start.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                Object source = e.getSource();
                if (source == start) {
                    f.remove(menucomponent);
                    f.revalidate();
                    f.repaint();

                        cweasel run = new cweasel();


                        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


                        f.add(run.layout);
                        f.pack();
                        f.setMinimumSize(f.getSize());
                        f.setVisible(true);

                }

            }
        });

        //Beginner
        JLabel begin = new JLabel();
        begin.setText("GRID: 4x4\nTRAPS:5");
        JButton beginner = new JButton("BEGINNER");

        beginner.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bombs = 5;
                size = 4;
            }
        });

        //Intermediate
        JLabel inter = new JLabel();

        inter.setText("GRID: 8x8\nTRAPS:14");
        JButton intermediate = new JButton("Intermediate");

        beginner.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bombs = 14;
                size = 8;
            }
        });

        //Expert
        JLabel exp = new JLabel();

        exp.setText("GRID: 15x15\nTRAPS:60");
        JButton expert = new JButton("EXPERT");

        beginner.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bombs = 60;
                size = 15;
            }
        });

        // slider grid
        JLabel numgrid = new JLabel();
        numgrid.setText("4");
        JLabel dirgrid = new JLabel();
        dirgrid.setText("SET GRID:");
        JSlider grid = new JSlider(4,15,4);
        grid.setMinorTickSpacing(2);
        grid.setPaintTrack(true);
        grid.setPaintTicks(true);
        grid.setPaintLabels(true);
        grid.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                numgrid.setText(String.valueOf(grid.getValue()));
                size = grid.getValue();

            }
        });
        slider.add(dirgrid);
        slider.add(grid);
        slider.add(numgrid);



        //slider bomb
        JLabel numbomb = new JLabel();
        numbomb.setText("5");
        JLabel dirbomb = new JLabel();
        dirbomb.setText("SET TRAPS:");
        JSlider bomb = new JSlider(5, 60,5);
        bomb.setMinorTickSpacing(2);
        bomb.setPaintTrack(true);
        bomb.setPaintTicks(true);
        bomb.setPaintLabels(true);
        bomb.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                numbomb.setText(String.valueOf(bomb.getValue()));
                bombs = bomb.getValue();
            }
        });
        slider.add(dirbomb);
        slider.add(bomb);
        slider.add(numbomb);


        menucomponent.add(startbutton);
        menucomponent.add(settings);
        settings.add(begin);
        settings.add(inter);
        settings.add(exp);
        settings.add(beginner);
        settings.add(intermediate);
        settings.add(expert);
        menucomponent.add(slider);
        menucomponent.setLayout(new GridLayout(3,1));

        f.add(menucomponent);
        f.pack();
        //f.setSize(f.getSize());
        f.setVisible(true);



    }

    ;


    class MineFieldModel {

        public int size;
        boolean[][] mineField;

        int numberMines;
        Random r = new Random();
        MineFieldModel(int size, int numberMines) {
            this.size = size;
            this.numberMines = numberMines;
            mineField = new boolean[size][size];

            ArrayList<Point> location = new ArrayList<>();
            for (int i = 0; i < this.size; i++) {
                for (int j = 0; j < size; j++) {
                    mineField[i][j] = false;


                    Point p = new Point(i, j);
                    location.add(p);
                }
            }
            Collections.shuffle(location, r);
            for (int i = 0; i < numberMines; i++) {
                Point p = location.get(i);
                mineField[p.x][p.y] = true;
            }
        }

        public boolean isBomb(int x, int y) {
            return mineField[x][y];
        }

        public int countSurroundingMines(int x, int y) {
            int lowX = x - 1;
            lowX = Math.max(lowX, 0);
            int highX = x + 2;
            highX = Math.min(highX, size);

            int lowY = y - 1;
            lowY = Math.max(lowY, 0);
            int highY = y + 2;
            highY = Math.min(highY, size);

            int count = 0;
            for (int i = lowX; i < highX; i++) {
                for (int j = lowY; j < highY; j++) {
                    if (i != x || j != y) {
                        if (mineField[i][j]) {
                            count++;
                        }
                    }
                }
            }
            return count;
        }
    }
}
