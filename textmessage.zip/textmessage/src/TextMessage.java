import java.awt.*;
import javax.swing.*;

//main for TextMessage
public class TextMessage {
    TextMessage(){
        //initialize variables for gaps between and above and below buttons
        int hgap = 1;
        int vgap = 2;

        //formulated arrays for each row of the keyboard (only strings in these arrays)
        String letters0[] = {"Type a message...", "Send"};
        String letters1[] = {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"};
        String letters2[] = {"A", "S", "D", "F", "G", "H", "J", "K", "L"};
        String letters3[] = {"Z", "X", "C", "V", "B", "N", "M"};
        String letters4[] = {"123", "space", "Return"};


        // creating new JFrame titled text message
        JFrame newFrame=new JFrame("Text Message");
        //set background color light blue
        newFrame.getContentPane().setBackground(Color.decode("#E9F5FF"));

        // Creating layout of frame with elements centered and space according to hgap and vgap
        newFrame.setLayout(new FlowLayout(FlowLayout.CENTER,hgap,vgap));

        //The following comments for the first button will apply to all subsequent buttons created.
        //first button: "+"
        JButton btn=new JButton("+");
        //set text color : DONE FOR EVERY BUTTON
        btn.setForeground(Color.BLUE);
        //set dimensions of button : DONE FOR EVERY BUTTON
        btn.setPreferredSize(new Dimension(30,40));
        //add button to frame : DONE FOR EVERY BUTTON
        newFrame.add(btn);

        //set frame size
        newFrame.setSize(280,250);
        //keep frame size from changing
        newFrame.setResizable(false);

        // text message... button
        JButton txt=new JButton("" + letters0[0]);
        txt.setPreferredSize(new Dimension(190,40));
        txt.setForeground(Color.BLUE);
        newFrame.add(txt);

        //send button
        JButton send=new JButton("" + letters0[1]);
        send.setPreferredSize(new Dimension(50,40));
        send.setForeground(Color.BLUE);
        newFrame.add(send);

        // for loop for first row of letters in keyboard from string letters1
        //the format of the for loops are the same so comments apply to subsequent for loops
        //loop through each element in array
        for (int i = 0; i<10; i++){
            //create new button
            JButton btn1= new JButton();
            //add button to frame
            newFrame.add(btn1);
            //set the text of button by concatenation of value that is stored at string index of i
            btn1.setText("" + letters1[i]);
            //set dimensions of button
            btn1.setPreferredSize(new Dimension(27,40));
            //set color of button text
            btn1.setForeground(Color.BLUE);

        }

        // for loop for second row of letters in keyboard from string letters2
        for (int i = 0; i<9; i++){
            JButton btn2= new JButton();
            newFrame.add(btn2);
            btn2.setText("" + letters2[i]);
            btn2.setPreferredSize(new Dimension(28,40));
            btn2.setForeground(Color.BLUE);

        }

        //up arrow for caps button (goes before start of iteration of letters3)
        //using unicode for arrow symbol
        JButton arrow = new JButton("\u2B06");
        newFrame.add(arrow);
        arrow.setPreferredSize(new Dimension(27,40));
        arrow.setForeground(Color.BLUE);

        // for loop for third row of letters in keyboard from string letters3
        for (int i = 0; i<7; i++){
            JButton btn3= new JButton();
            newFrame.add(btn3);
            btn3.setText("" + letters3[i]);
            btn3.setPreferredSize(new Dimension(27,40));
            btn3.setForeground(Color.BLUE);

        }

        //arrow for backspace button (goes after the iteration of letters3)
        //using unicode for arrow symbol
        JButton Larrow = new JButton("\u140A");
        newFrame.add(Larrow);
        Larrow.setPreferredSize(new Dimension(27,40));
        Larrow.setForeground(Color.BLUE);

        //numbers button from letters4 array
        JButton num = new JButton(""+letters4[0]);
        newFrame.add(num);
        num.setPreferredSize(new Dimension(40,40));
        num.setForeground(Color.BLUE);

        //emoji button
        //using unicode for emoji symbol
        JButton emoji = new JButton("\u263A");
        newFrame.add(emoji);
        emoji.setPreferredSize(new Dimension(30,40));
        emoji.setForeground(Color.BLUE);

        //microphone button
        //using unicode for wave symbol (simulate sound wave could not use emoji unicode)
        JButton mic = new JButton("\u223F");
        newFrame.add(mic);
        mic.setPreferredSize(new Dimension(30,40));
        mic.setForeground(Color.BLUE);

        //space button
        JButton space = new JButton(""+letters4[1]);
        newFrame.add(space);
        space.setPreferredSize(new Dimension(60,40));
        space.setForeground(Color.BLUE);

        //return button
        JButton ret = new JButton(""+letters4[2]);
        newFrame.add(ret);
        ret.setPreferredSize(new Dimension(70,40));
        ret.setForeground(Color.BLUE);

        //set frame to visible to make keyboard show up
        newFrame.setVisible(true);
        //exit frame upon hitting the red x to close
        newFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    //call to main
    public static void main(String[] args) {
        new TextMessage();
    }
}

